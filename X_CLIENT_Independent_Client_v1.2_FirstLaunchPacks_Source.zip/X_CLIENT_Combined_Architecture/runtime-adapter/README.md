# Native Bedrock Integration — v0.8 provider contract

Added `include/xclient/ProviderContract.hpp` as the explicit lifecycle contract between the portable C++ module engine and a future host adapter. It defines initialization, bridge/renderer access, and shutdown. It is intentionally an interface, not a working Minecraft connection.

## Why there is no live provider yet
The public Bedrock Script API exposes selected gameplay data and UI methods, but it does not expose a general native C++ plugin ABI or a supported route for a third-party native library to draw over the game's renderer. A provider cannot be implemented honestly without a supported host-side API or a lawful, compatible runtime that we control.

Next steps for a real provider:
1. Select a host/runtime with a documented extension ABI or use supported Bedrock scripting for features it exposes.
2. Implement a provider only against that interface.
3. Mark builds as supported only after integration tests on real devices.
4. Keep the addon implementation separate from native modules where no bridge exists.

No process injection, memory scanning, binary patching, or proprietary Bedrock code is included.
