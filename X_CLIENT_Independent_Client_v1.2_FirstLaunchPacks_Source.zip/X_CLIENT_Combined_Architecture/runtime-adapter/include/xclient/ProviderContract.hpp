#pragma once
#include <cstdint>
#include <string>
#include "xclient/RuntimeApi.hpp"

namespace xclient::adapter {
// Integration contract only. A provider must be backed by a documented and
// authorized API exposed by the host/runtime; this project does not implement
// a Bedrock native provider or read Minecraft process memory.
struct ProviderDescriptor {
    std::string providerName;
    std::string providerVersion;
    std::string targetGameVersion;
    std::uint32_t runtimeApiVersion{kRuntimeApiVersion};
};

class IProviderLifecycle {
public:
    virtual ~IProviderLifecycle() = default;
    virtual bool initialize(const ProviderDescriptor& descriptor, std::string& error) = 0;
    virtual IGameBridge* gameBridge() = 0;
    virtual IOverlayRenderer* overlayRenderer() = 0;
    virtual void shutdown() = 0;
};
} // namespace xclient::adapter
