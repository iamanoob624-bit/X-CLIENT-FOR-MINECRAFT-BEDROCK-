# XEngine — independent-engine research scaffold (v0.8)

This folder starts a clean-room engine architecture for X CLIENT. It is **not a Minecraft Bedrock replacement**, does not load Bedrock worlds, and is not network-compatible with Minecraft servers. Building a compatible engine is a major separate project; adding a few C++ classes cannot reproduce Bedrock's world format, gameplay, renderer, assets, or protocol.

## Included
- A minimal engine lifecycle interface and fixed-tick loop contract.
- A tiny voxel-world data model with no Minecraft-specific code or assets.
- A roadmap for renderer, input, persistence, and protocol research.

The prototype deliberately uses original sample data and does not bundle proprietary game code/assets.
