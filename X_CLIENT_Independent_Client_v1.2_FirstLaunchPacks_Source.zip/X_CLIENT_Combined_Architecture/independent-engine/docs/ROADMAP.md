# XEngine roadmap

1. **Prototype (v0.8):** original voxel storage model and renderer interface.
2. **Renderer:** implement an OpenGL ES renderer on Android and draw original sample worlds.
3. **Input/camera:** touch controls, camera transforms, basic collision.
4. **World persistence:** documented original file format and save/load tests.
5. **Gameplay:** original block interaction and entity simulation.
6. **Compatibility research:** study publicly documented formats and protocols; no claim of Minecraft/Bedrock compatibility without a separate legal and technical assessment.

This is a standalone original voxel engine starter, not a Bedrock engine or Minecraft-compatible client.
