#include "xengine/Engine.hpp"
#include <stdexcept>
#include <utility>

namespace xengine {
VoxelWorld::VoxelWorld(WorldSize size) : size_(size) {
    if (!size.x || !size.y || !size.z) throw std::invalid_argument("world dimensions must be nonzero");
    blocks_.resize(static_cast<std::uint64_t>(size.x) * size.y * size.z);
}
std::uint64_t VoxelWorld::index(std::uint32_t x, std::uint32_t y, std::uint32_t z) const {
    if (x >= size_.x || y >= size_.y || z >= size_.z) throw std::out_of_range("voxel coordinate out of range");
    return (static_cast<std::uint64_t>(y) * size_.z + z) * size_.x + x;
}
bool VoxelWorld::set(std::uint32_t x, std::uint32_t y, std::uint32_t z, Block block) {
    try { blocks_[index(x,y,z)] = block; return true; } catch (const std::out_of_range&) { return false; }
}
Block VoxelWorld::get(std::uint32_t x, std::uint32_t y, std::uint32_t z) const { return blocks_[index(x,y,z)]; }
Engine::Engine(VoxelWorld world) : world_(std::move(world)) {}
bool Engine::start(IRenderer& renderer, std::string& error) {
    if (renderer_) { error = "engine already started"; return false; }
    if (!renderer.initialize(error)) return false;
    renderer_ = &renderer;
    return true;
}
void Engine::renderFrame() {
    if (!renderer_) return;
    renderer_->beginFrame();
    const auto s = world_.size();
    for (std::uint32_t y=0; y<s.y; ++y)
        for (std::uint32_t z=0; z<s.z; ++z)
            for (std::uint32_t x=0; x<s.x; ++x) {
                const auto block = world_.get(x,y,z);
                if (block.material) renderer_->drawVoxel(x,y,z,block);
            }
    renderer_->endFrame();
}
void Engine::stop() { if (renderer_) { renderer_->shutdown(); renderer_ = nullptr; } }
} // namespace xengine
