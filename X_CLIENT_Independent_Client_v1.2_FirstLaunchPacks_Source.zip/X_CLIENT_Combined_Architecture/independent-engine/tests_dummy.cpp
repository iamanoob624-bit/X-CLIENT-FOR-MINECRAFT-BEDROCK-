#include "xengine/Engine.hpp"
#include <cassert>
int main() {
    xengine::VoxelWorld world({4,4,4});
    assert(world.set(1,2,3,{7}));
    assert(world.get(1,2,3).material == 7);
    assert(!world.set(4,2,3,{8}));
    return 0;
}
