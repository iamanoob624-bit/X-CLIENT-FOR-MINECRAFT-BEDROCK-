#pragma once
#include <cstdint>
#include <functional>
#include <string>
#include <vector>

namespace xengine {
struct Block { std::uint16_t material{0}; };
struct WorldSize { std::uint32_t x{16}, y{16}, z{16}; };

class VoxelWorld {
public:
    explicit VoxelWorld(WorldSize size);
    bool set(std::uint32_t x, std::uint32_t y, std::uint32_t z, Block block);
    Block get(std::uint32_t x, std::uint32_t y, std::uint32_t z) const;
    WorldSize size() const { return size_; }
private:
    WorldSize size_;
    std::vector<Block> blocks_;
    std::uint64_t index(std::uint32_t x, std::uint32_t y, std::uint32_t z) const;
};

class IRenderer {
public:
    virtual ~IRenderer() = default;
    virtual bool initialize(std::string& error) = 0;
    virtual void beginFrame() = 0;
    virtual void drawVoxel(std::uint32_t x, std::uint32_t y, std::uint32_t z, Block block) = 0;
    virtual void endFrame() = 0;
    virtual void shutdown() = 0;
};

class Engine {
public:
    explicit Engine(VoxelWorld world);
    bool start(IRenderer& renderer, std::string& error);
    void renderFrame();
    void stop();
    VoxelWorld& world() { return world_; }
private:
    VoxelWorld world_;
    IRenderer* renderer_{nullptr};
};
} // namespace xengine
