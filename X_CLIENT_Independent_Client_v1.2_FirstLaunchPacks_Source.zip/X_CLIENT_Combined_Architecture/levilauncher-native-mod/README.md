# X CLIENT native mod starter

This subproject targets LeviLauncher/Preloader, which supplies the Bedrock runtime. It is not a standalone launcher.

Build for Android `arm64-v8a` with Android NDK and CMake. The project references the public `preloader-android` SDK. Verify the SDK tag and API against your installed LeviLauncher version before building.

The starter only registers lifecycle methods and logs load/enable/disable/unload. It intentionally does not include unverified game hooks, offsets, HUD drawing, or BedrockTools compatibility code.
