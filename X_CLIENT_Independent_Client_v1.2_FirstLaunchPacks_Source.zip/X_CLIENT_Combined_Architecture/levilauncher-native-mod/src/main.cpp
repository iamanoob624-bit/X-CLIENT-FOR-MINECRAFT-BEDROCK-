#include <pl/Mod.hpp>
#include <filesystem>

class XClientNativeMod {
public:
    static XClientNativeMod& instance() { static XClientNativeMod mod; return mod; }
    XClientNativeMod() : self_(*ll::mod::NativeMod::current()) {}
    [[nodiscard]] ll::mod::NativeMod& getSelf() const { return self_; }
    bool load() {
        std::error_code ec;
        std::filesystem::create_directories(self_.getConfigDir(), ec);
        if (ec) { self_.getLogger().error("Could not create config directory: {}", ec.message()); return false; }
        self_.getLogger().info("X CLIENT loaded. No game hooks are enabled in this starter.");
        return true;
    }
    bool enable() { self_.getLogger().info("X CLIENT enabled."); return true; }
    bool disable() { self_.getLogger().info("X CLIENT disabled."); return true; }
    bool unload() { self_.getLogger().info("X CLIENT unloaded."); return true; }
private:
    ll::mod::NativeMod& self_;
};
PL_REGISTER_MOD(XClientNativeMod, XClientNativeMod::instance())
