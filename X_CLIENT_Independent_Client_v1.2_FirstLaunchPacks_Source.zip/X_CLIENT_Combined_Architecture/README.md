# X CLIENT v1.0 — User Pack Import + CurseForge API + Bedrock Add-ons + Runtime Scaffolds

This release adds three development tracks without misrepresenting incomplete integrations as working:

1. **Custom center crosshair:** an experimental Bedrock resource pack replaces `textures/ui/cross_hair.png` with an original cyan reticle. It is version-sensitive and not yet verified on device.
2. **Native C++ provider contract:** `runtime-adapter/include/xclient/ProviderContract.hpp` defines lifecycle boundaries for a future authorized integration. It is not a live Bedrock native connection. Public Script API does not expose a general native C++ plugin/rendering ABI.
3. **Independent engine starter:** `independent-engine/` contains an original voxel-world model and renderer interface. It is a clean-room prototype, not a Bedrock replacement and not compatible with Minecraft worlds/servers.

The supported Bedrock Script API HUD remains in `bedrock-addon/X_CLIENT_HUD_BP/`. The Android launcher remains a source project and has not been built/device-tested in this environment.

## Build portable C++ module core
```sh
cmake -S runtime-core -B build-runtime
cmake --build build-runtime -j2
ctest --test-dir build-runtime --output-on-failure
```

## Build the independent voxel prototype
```sh
cmake -S independent-engine -B build-engine
cmake --build build-engine -j2
ctest --test-dir build-engine --output-on-failure
```

## Pack files
- `X_CLIENT_HUD_BP_v0.8.mcpack`: behavior/script pack.
- `X_CLIENT_Crosshair_RP_v0.8.mcpack`: experimental resource pack.
- `X_CLIENT_Gameplay_Addons_v0.8.mcaddon`: convenience bundle containing both packs.

## Honest limitations
- No Bedrock native bridge/provider is implemented.
- The custom crosshair texture override is experimental and unverified on device.
- The independent engine is only a starter, not a complete game engine or Minecraft clone.
- No APK has been built or tested on an Android device.


## v0.9 Resource Pack Manager
- Android launcher includes a local pack library for `.mcpack`, `.mcaddon`, and `.zip` files.
- Search uses CurseForge Core API `GET /v1/mods/search`; downloads resolve via `GET /v1/mods/{modId}/files/{fileId}/download-url`.
- Requires a valid approved CurseForge API key entered by the user at runtime; no API key is embedded in source. Key is stored in private app preferences. For a public production release, use a backend proxy so a shared developer API key is not shipped in the APK.
- Game ID and class ID are configurable because catalogue visibility and classes depend on CurseForge configuration. Defaults are gameId `432` and classId `4559` (Minecraft Addons); confirm the catalogue and category IDs for Bedrock texture packs accessible to your API key.
- Download safety: HTTPS only, redirect limit, CurseForge-host key restriction, 128 MiB size cap, and only `.mcpack`, `.mcaddon`, or `.zip` filename extensions accepted.
- Packs are downloaded into X CLIENT private storage. The app can request Android to hand a file to Minecraft for import, but does not silently write into Minecraft's private directories or auto-enable packs in worlds.
- Android INTERNET permission added. API implementation follows CurseForge's documented `x-api-key` requirement.

## Resource manager setup
1. Open Android Studio and build/install the `launcher-app` project.
2. Open `PACKS`, enter your approved CurseForge API key, and verify game/class IDs with the CurseForge catalog.
3. Search, download a pack, then tap **IMPORT INTO MINECRAFT**.
4. Confirm Minecraft's import result and activate the pack in a world/global resources settings.

The launcher APK has not been built or device-tested in this environment; API behavior requires a valid key and network access.


## v1.0 User-selected pack import

The Resource Packs screen now puts **Import Your Own Pack** at the top. Users can choose `.mcpack`, `.mcaddon`, or `.zip` files through Android's system document picker. X CLIENT copies selected files (maximum 64 MiB) to its private local pack library, lists them, and offers an **Import into Minecraft** handoff action. Users can also delete packs or import additional files.

Importing into X CLIENT is separate from importing/activating inside Minecraft: Android/Minecraft must accept the handoff, and the user may need to confirm the import in Minecraft. Compatibility is not guaranteed for every archive or Bedrock version.

## Automatic pack handoff (Android limitation)

The launcher includes an opt-out `AUTO-SEND QUEUED PACKS WHEN LAUNCHING MINECRAFT` setting, enabled by default. Newly imported/downloaded packs are queued until X CLIENT sends them to Minecraft using an Android `ACTION_VIEW` file handoff. The launcher sends one pending pack per launch-button press; if multiple packs are queued, return to X CLIENT and press Launch Minecraft again for the next one. The sent list means only that the handoff intent was launched—it cannot verify Minecraft completed the import or activated the pack.

Android does not allow an ordinary app to silently write into Minecraft's private data directory. Minecraft may show an import confirmation, and world/resource-pack activation can still require user action. This feature automates the handoff, not a guaranteed silent install.


## v1.2 first-launch bundled pack queue

On the first app launch, X CLIENT copies the three bundled example files (`X_CLIENT_Gameplay_Addons_v0.8.mcaddon`, `X_CLIENT_HUD_BP_v0.8.mcpack`, and `X_CLIENT_Crosshair_RP_v0.8.mcpack`) from Android assets into its private pack library. The packs are queued for handoff when the user chooses **LAUNCH MINECRAFT**. The queue hands off one file per launch-button press because Android/Minecraft may handle each file as a separate import intent. The user can requeue these examples from the Resource Packs screen.

**Platform limitation:** this seeds X CLIENT's library automatically; it cannot silently write into Minecraft's private app storage, bypass Minecraft's import confirmation, or auto-activate packs in a world. A `.zip` selected by the user is supported by the existing import flow if it is a compatible pack archive. The Android Studio source `.zip` is not itself a Minecraft pack and is not imported into Minecraft.
