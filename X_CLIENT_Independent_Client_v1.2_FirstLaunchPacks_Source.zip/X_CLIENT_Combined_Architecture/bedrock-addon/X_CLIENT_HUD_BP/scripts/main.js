import { world, system } from "@minecraft/server";

const MODULES = {
  coords: true,
  compass: true,
  sprint: true,
  marker: false
};
const PREFIX = "§b[X CLIENT]§r ";
let tick = 0;

function directionFromYaw(yaw) {
  const angle = ((yaw % 360) + 360) % 360;
  if (angle >= 315 || angle < 45) return "S";
  if (angle < 135) return "W";
  if (angle < 225) return "N";
  return "E";
}

function statusText() {
  return Object.entries(MODULES)
    .map(([name, enabled]) => `${name}:${enabled ? "ON" : "OFF"}`)
    .join("  ");
}

function showHelp(player) {
  player.sendMessage(`${PREFIX}Commands: /scriptevent xclient:toggle coords|compass|sprint|marker`);
  player.sendMessage(`${PREFIX}Status: /scriptevent xclient:status`);
  player.sendMessage(`${PREFIX}HUD is rendered through Bedrock's supported action-bar API.`);
}

system.afterEvents.scriptEventReceive.subscribe((event) => {
  if (event.id === "xclient:status") {
    const player = event.sourceEntity;
    if (player && player.typeId === "minecraft:player") {
      player.sendMessage(`${PREFIX}${statusText()}`);
    }
    return;
  }

  if (event.id !== "xclient:toggle") return;
  const player = event.sourceEntity;
  if (!player || player.typeId !== "minecraft:player") return;

  const key = String(event.message ?? "").trim().toLowerCase();
  if (!(key in MODULES)) {
    showHelp(player);
    return;
  }
  MODULES[key] = !MODULES[key];
  player.sendMessage(`${PREFIX}${key} ${MODULES[key] ? "enabled" : "disabled"}.`);
});

world.afterEvents.playerSpawn.subscribe(({ player, initialSpawn }) => {
  if (initialSpawn) {
    player.sendMessage(`${PREFIX}HUD loaded. Use /scriptevent xclient:status for module status.`);
  }
});

system.runInterval(() => {
  tick++;
  // Refresh five times per second; this is enough for a readable HUD and avoids
  // needlessly sending an action-bar update every game tick.
  if (tick % 4 !== 0) return;

  for (const player of world.getAllPlayers()) {
    try {
      const parts = [];
      if (MODULES.coords) {
        const p = player.location;
        parts.push(`§bXYZ§f ${Math.floor(p.x)} ${Math.floor(p.y)} ${Math.floor(p.z)}`);
      }
      if (MODULES.compass) {
        const yaw = player.getRotation().y;
        parts.push(`§dDIR§f ${directionFromYaw(yaw)}`);
      }
      if (MODULES.sprint) {
        const sprinting = typeof player.isSprinting === "boolean" ? player.isSprinting : false;
        parts.push(`§eSPRINT§f ${sprinting ? "ON" : "OFF"}`);
      }
      if (MODULES.marker) parts.push("§a+§r");
      if (parts.length) player.onScreenDisplay.setActionBar(parts.join("  §8|§r  "));
    } catch (error) {
      // A single player/API issue should not stop updates for other players.
    }
  }
}, 1);
