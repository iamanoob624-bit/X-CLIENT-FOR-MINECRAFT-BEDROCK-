# X CLIENT Crosshair Resource Pack (experimental)

This resource pack replaces the conventional Bedrock UI crosshair texture at `textures/ui/cross_hair.png` with a custom cyan, outlined reticle. It does not inject code into Minecraft and does not provide arbitrary native overlay drawing.

## Install
1. Import the `.mcpack` into Minecraft.
2. Activate it in the world's Resource Packs list (or globally in Settings > Global Resources).
3. Test in a throwaway world first. If your game version uses a different UI texture key or pack precedence changes the result, the vanilla crosshair may remain unchanged.

## Compatibility
This is a version-sensitive resource override, not an official public custom-crosshair API. It is not yet device-tested. To restore the default, disable this resource pack.
