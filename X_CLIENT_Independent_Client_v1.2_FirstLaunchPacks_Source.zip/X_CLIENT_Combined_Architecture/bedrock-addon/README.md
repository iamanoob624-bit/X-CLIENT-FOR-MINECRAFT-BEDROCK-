# X CLIENT Bedrock Add-ons

- `X_CLIENT_HUD_BP`: gameplay HUD using the public Script API (coordinates, heading, sprint indicator/action bar).
- `X_CLIENT_Crosshair_RP`: experimental resource-pack texture override for a custom cyan crosshair.

These are distinct packs because Bedrock behavior packs and resource packs have separate manifests and activation flows. The crosshair override depends on the UI texture key used by the installed Bedrock version and has not been device-tested.
