#include "xclient/RuntimeApi.hpp"
#include <cmath>
#include <memory>

namespace xclient { namespace {
class Coordinates final : public IModule {
    bool enabled_{false};
public:
    ModuleInfo info() const override { return {"coords", "Player Coordinates", "HUD", "Displays the local player's X/Y/Z from the runtime bridge.", enabled_}; }
    void setEnabled(bool v) override { enabled_ = v; }
    void tick(const GameSnapshot& s, IOverlayRenderer& r) override {
        if (enabled_ && s.inWorld && s.hasLocalPlayer) {
            r.text(12, 18, "XYZ  " + std::to_string(static_cast<int>(std::floor(s.position.x))) + " / " +
                std::to_string(static_cast<int>(std::floor(s.position.y))) + " / " +
                std::to_string(static_cast<int>(std::floor(s.position.z))));
        }
    }
};
class SprintStatus final : public IModule {
    bool enabled_{false};
public:
    ModuleInfo info() const override { return {"sprint", "Sprint Status", "HUD", "Shows sprint state from the runtime bridge.", enabled_}; }
    void setEnabled(bool v) override { enabled_ = v; }
    void tick(const GameSnapshot& s, IOverlayRenderer& r) override {
        if (enabled_ && s.inWorld && s.hasLocalPlayer) r.text(12, 38, s.sprinting ? "SPRINT: ON" : "SPRINT: OFF");
    }
};
class Compass final : public IModule {
    bool enabled_{false};
public:
    ModuleInfo info() const override { return {"compass", "Compass HUD", "HUD", "Converts player yaw to a compass heading.", enabled_}; }
    void setEnabled(bool v) override { enabled_ = v; }
    void tick(const GameSnapshot& s, IOverlayRenderer& r) override {
        if (!enabled_ || !s.inWorld || !s.hasLocalPlayer) return;
        float yaw = std::fmod(s.yawDegrees, 360.0F); if (yaw < 0) yaw += 360.0F;
        static const char* dirs[] = {"S", "SW", "W", "NW", "N", "NE", "E", "SE"};
        const int index = static_cast<int>(std::floor((yaw + 22.5F) / 45.0F)) % 8;
        r.text(12, 58, std::string("HEADING: ") + dirs[index] + " " + std::to_string(static_cast<int>(yaw)) + " deg");
    }
};
class Crosshair final : public IModule {
    bool enabled_{false};
public:
    ModuleInfo info() const override { return {"crosshair", "Crosshair Guide", "VISUAL", "Draws a simple guide at the overlay center.", enabled_}; }
    void setEnabled(bool v) override { enabled_ = v; }
    void tick(const GameSnapshot& s, IOverlayRenderer& r) override {
        if (enabled_ && s.inWorld) { r.line(156, 120, 168, 120); r.line(162, 114, 162, 126); r.circle(162, 120, 3); }
    }
};
} // namespace

ModuleManager::ModuleManager() {
    modules_.push_back(std::make_unique<Coordinates>());
    modules_.push_back(std::make_unique<Compass>());
    modules_.push_back(std::make_unique<SprintStatus>());
    modules_.push_back(std::make_unique<Crosshair>());
}
bool ModuleManager::setEnabled(const std::string& id, bool enabled) {
    for (auto& m : modules_) if (m->info().id == id) { m->setEnabled(enabled); return true; }
    return false;
}
std::vector<ModuleInfo> ModuleManager::list() const {
    std::vector<ModuleInfo> out; out.reserve(modules_.size());
    for (const auto& m : modules_) out.push_back(m->info());
    return out;
}
bool ModuleManager::tick(IGameBridge* bridge, IOverlayRenderer& renderer, std::string& status) {
    if (!bridge) { status = "No game bridge connected"; return false; }
    if (bridge->apiVersion() != kRuntimeApiVersion) { status = "Runtime API version mismatch"; return false; }
    if (!bridge->isSupportedBuild()) { status = "Game build is not verified for this bridge"; return false; }
    GameSnapshot snapshot;
    if (!bridge->readSnapshot(snapshot)) { status = "Game state unavailable"; return false; }
    for (auto& module : modules_) module->tick(snapshot, renderer);
    status = "Connected to verified bridge for " + bridge->gameVersion();
    return true;
}
} // namespace xclient
