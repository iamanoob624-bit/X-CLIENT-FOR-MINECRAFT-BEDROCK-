#include "xclient/RuntimeApi.hpp"
#include <cassert>
#include <iostream>
#include <string>
#include <vector>
using namespace xclient;
struct Renderer final : IOverlayRenderer {
    std::vector<std::string> texts; int lines=0, circles=0;
    void text(float, float, const std::string& s) override { texts.push_back(s); }
    void line(float, float, float, float) override { ++lines; }
    void circle(float, float, float) override { ++circles; }
};
struct FakeBridge final : IGameBridge {
    GameSnapshot state{true, true, {12.8, 64.0, -4.2}, 0.0F, true, 45};
    std::uint32_t apiVersion() const override { return kRuntimeApiVersion; }
    std::string gameVersion() const override { return "TEST-HOST-1"; }
    bool isSupportedBuild() const override { return true; }
    bool readSnapshot(GameSnapshot& out) override { out=state; return true; }
};
int main() {
    ModuleManager manager; Renderer renderer; std::string status;
    assert(!manager.tick(nullptr, renderer, status));
    assert(status == "No game bridge connected");
    assert(manager.setEnabled("coords", true));
    assert(manager.setEnabled("sprint", true));
    assert(manager.setEnabled("compass", true));
    assert(manager.setEnabled("crosshair", true));
    FakeBridge bridge;
    assert(manager.tick(&bridge, renderer, status));
    assert(renderer.texts.size() == 3);
    assert(renderer.texts[0].find("XYZ  12 / 64 / -5") != std::string::npos);
    assert(renderer.texts[1] == "HEADING: S 0 deg");
    assert(renderer.texts[2] == "SPRINT: ON");
    assert(renderer.lines == 2 && renderer.circles == 1);
    assert(manager.setEnabled("sprint", false));
    Renderer second; assert(manager.tick(&bridge, second, status));
    assert(second.texts.size() == 2);
    std::cout << "X CLIENT runtime-core tests passed.\n";
}
