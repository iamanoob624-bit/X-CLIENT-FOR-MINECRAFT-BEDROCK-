# X CLIENT Runtime Core (v0.5 foundation)

This is a portable C++20 module engine with a deliberately narrow game bridge interface.
It includes functional module logic for coordinates, compass heading, sprint state, and a crosshair guide. Modules consume a `GameSnapshot` supplied by an `IGameBridge` and draw through `IOverlayRenderer`.

## Build and test on a desktop

```sh
cmake -S . -B build
cmake --build build
ctest --test-dir build --output-on-failure
```

The included fake bridge is only a test harness. It proves the module engine logic and lifecycle work with a provider; it is **not Minecraft integration**.

## How real game integration is added

A legitimate runtime provider must implement `IGameBridge` for a documented integration API, publish the correct API version, and explicitly mark only tested game builds as supported. The core refuses to draw when the bridge is absent, mismatched, or reports an unverified game build.

No Bedrock memory scanning, process injection, proprietary game binary, or undocumented game hook is included. Those are not substitutes for a stable supported API. Until a real provider is implemented and tested, these modules do not render inside Minecraft.
