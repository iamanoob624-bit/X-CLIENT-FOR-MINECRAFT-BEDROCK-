#pragma once
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

namespace xclient {
inline constexpr std::uint32_t kRuntimeApiVersion = 1;

struct Vec3 { double x{}, y{}, z{}; };
struct GameSnapshot {
    bool inWorld{false};
    bool hasLocalPlayer{false};
    Vec3 position{};
    float yawDegrees{0.0F};
    bool sprinting{false};
    int pingMs{-1};
};

// The real game integration must implement this interface using a documented,
// version-compatible provider. The core never reads Minecraft memory itself.
class IGameBridge {
public:
    virtual ~IGameBridge() = default;
    virtual std::uint32_t apiVersion() const = 0;
    virtual std::string gameVersion() const = 0;
    virtual bool isSupportedBuild() const = 0;
    virtual bool readSnapshot(GameSnapshot& out) = 0;
};

class IOverlayRenderer {
public:
    virtual ~IOverlayRenderer() = default;
    virtual void text(float x, float y, const std::string& value) = 0;
    virtual void line(float x1, float y1, float x2, float y2) = 0;
    virtual void circle(float cx, float cy, float radius) = 0;
};

struct ModuleInfo { std::string id, name, category, description; bool enabled{false}; };

class IModule {
public:
    virtual ~IModule() = default;
    virtual ModuleInfo info() const = 0;
    virtual void setEnabled(bool enabled) = 0;
    virtual void tick(const GameSnapshot& state, IOverlayRenderer& renderer) = 0;
};

class ModuleManager {
public:
    ModuleManager();
    bool setEnabled(const std::string& id, bool enabled);
    std::vector<ModuleInfo> list() const;
    // Returns false and draws nothing unless a valid supported game bridge is present.
    bool tick(IGameBridge* bridge, IOverlayRenderer& renderer, std::string& status);
private:
    std::vector<std::unique_ptr<IModule>> modules_;
};
} // namespace xclient
