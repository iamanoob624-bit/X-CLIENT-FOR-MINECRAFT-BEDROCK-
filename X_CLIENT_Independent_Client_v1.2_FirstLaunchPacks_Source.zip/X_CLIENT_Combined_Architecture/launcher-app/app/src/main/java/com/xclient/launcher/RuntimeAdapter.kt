package com.xclient.launcher

/** Runtime boundary: add a verified implementation when a documented integration is selected. */
interface RuntimeAdapter {
    fun displayName(): String
    fun isAvailable(): Boolean
    fun launch(): RuntimeResult
}
data class RuntimeResult(val success: Boolean, val message: String)
class LeviLauncherHandoffAdapter : RuntimeAdapter {
    override fun displayName() = "LeviLauncher handoff"
    override fun isAvailable() = false // Do not mark available until a supported integration is verified.
    override fun launch() = RuntimeResult(false, "No documented launch integration configured. Open LeviLauncher directly for now.")
}
