package com.xclient.launcher

import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.content.Intent
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.text.Editable
import android.text.TextWatcher
import android.widget.*
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

/** X CLIENT v0.4: cyber dashboard, local module manager, and Minecraft package detection.
 * Native imports are inspected and stored only; imported code is never loaded or injected.
 */
class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private lateinit var status: TextView
    private lateinit var navScroll: HorizontalScrollView
    private val gamePackage = "com.mojang.minecraftpe"
    private val nativeDir by lazy { File(filesDir, "native-modules").apply { mkdirs() } }
    private val packageDir by lazy { File(filesDir, "packages").apply { mkdirs() } }
    private val profilesDir by lazy { File(filesDir, "profiles").apply { mkdirs() } }
    private val packsDir by lazy { File(filesDir, "packs").apply { mkdirs() } }
    private val prefs by lazy { getSharedPreferences("xclient", MODE_PRIVATE) }
    private val modules = listOf(
        Module("coords", "Player Coordinates", "HUD", "Native module logic is implemented; needs a verified Bedrock game bridge"),
        Module("compass", "Compass HUD", "HUD", "Native heading logic is implemented; needs a verified Bedrock game bridge"),
        Module("fps", "Performance Panel", "UTILITY", "Performance display adapter placeholder"),
        Module("crosshair", "Crosshair Guide", "VISUAL", "Native overlay drawing logic is implemented; needs a game overlay provider"),
        Module("sprint", "Sprint Status", "HUD", "Native sprint indicator logic is implemented; needs a verified Bedrock game bridge"),
        Module("lowfx", "Low Effects Preset", "PERFORMANCE", "Local preset toggle; does not change game settings"),
        Module("zoom", "Zoom Control", "VISUAL", "Runtime adapter required"),
        Module("keystrokes", "Input Display", "HUD", "Runtime adapter required"),
        Module("ping", "Ping Counter", "HUD", "Runtime adapter required"),
        Module("timestamps", "Chat Timestamps", "UTILITY", "Runtime adapter required")
    )
    companion object { private const val PICK_NATIVE = 701; private const val PICK_PACKAGE = 702; private const val PICK_RESOURCE_PACK = 703 }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        seedBundledPacksOnFirstLaunch()
        buildShell()
        showDashboard()
    }


    /** Copies the built-in example packs into X CLIENT's private library once.
     * Android/Minecraft may still require a user-confirmed handoff; this cannot
     * silently write into Minecraft's private data directory.
     */
    private fun seedBundledPacksOnFirstLaunch() {
        if (prefs.getBoolean("bundled_packs_seeded_v1", false)) return
        val assets = listOf(
            "X_CLIENT_Gameplay_Addons_v0.8.mcaddon",
            "X_CLIENT_HUD_BP_v0.8.mcpack",
            "X_CLIENT_Crosshair_RP_v0.8.mcpack"
        )
        val copied = mutableListOf<String>()
        try {
            val assetNames = assetsDirNames("default-packs")
            assets.forEach { name ->
                if (name !in assetNames) return@forEach
                val dest = File(packsDir, name)
                if (!dest.exists()) assets.open("default-packs/$name").use { input -> dest.outputStream().use { output -> input.copyTo(output) } }
                copied.add(name)
            }
            // Mark the included packs as queued, not already handed off.
            val sent = (prefs.getStringSet("packs_handed_off", emptySet()) ?: emptySet()).toMutableSet()
            copied.forEach { sent.remove(it) }
            prefs.edit().putStringSet("packs_handed_off", sent).putBoolean("bundled_packs_seeded_v1", true).apply()
            if (copied.isNotEmpty()) prefs.edit().putBoolean("show_first_run_pack_notice", true).apply()
        } catch (e: Exception) {
            statusOrNoop("Could not seed bundled packs: ${e.message ?: "unknown error"}")
        }
    }

    private fun assetsDirNames(path: String): List<String> = try { assets.list(path)?.toList() ?: emptyList() } catch (_: Exception) { emptyList() }
    private fun statusOrNoop(message: String) { android.util.Log.w("X_CLIENT", message) }

    private fun buildShell() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(20), dp(16), dp(12))
            setBackgroundColor(0xFF070B14.toInt())
        }
        root.addView(TextView(this).apply {
            text = "X CLIENT"
            textSize = 30f; typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            setTextColor(0xFF55F4FF.toInt()); letterSpacing = 0.11f
        })
        root.addView(TextView(this).apply {
            text = "X-CORE  /  INDEPENDENT CLIENT PLATFORM  /  v1.2"
            textSize = 10f; setTextColor(0xFF8CA2BF.toInt()); setPadding(0, dp(2), 0, dp(12))
        })
        status = TextView(this).apply {
            text = "SYSTEM READY  //  GAME RUNTIME NOT CONNECTED"
            textSize = 11f; typeface = Typeface.MONOSPACE; setTextColor(0xFFFFC66D.toInt())
            setPadding(dp(12), dp(10), dp(12), dp(10)); setBackgroundColor(0xFF151B29.toInt())
        }
        root.addView(status)
        navScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(8), 0, dp(8)) }
        listOf("HOME", "MODULES", "PROFILES", "PACKS", "GAME", "IMPORT", "RUNTIME", "SETTINGS").forEach { label ->
            nav.addView(Button(this).apply {
                text = label; textSize = 10f; isAllCaps = false; minWidth = dp(72)
                setTextColor(0xFF55F4FF.toInt())
                setOnClickListener { when(label) {
                    "HOME" -> showDashboard()
                    "MODULES" -> showModules()
                    "PROFILES" -> showProfiles()
                    "PACKS" -> showResourcePacks()
                    "GAME" -> showGameDetection()
                    "IMPORT" -> showImports()
                    "RUNTIME" -> showRuntime()
                    else -> showSettings()
                } }
            }, LinearLayout.LayoutParams(-2, -2))
        }
        navScroll.addView(nav); root.addView(navScroll)
        val scroller = ScrollView(this)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(2), 0, dp(12)) }
        scroller.addView(content)
        root.addView(scroller, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(TextView(this).apply {
            text = "ANDROID 9–16 TARGET  •  BEDROCK ADAPTER NOT CONNECTED"
            textSize = 9f; gravity = Gravity.CENTER; setTextColor(0xFF60738E.toInt()); setPadding(0, dp(8), 0, 0)
        })
        setContentView(root)
    }

    private fun heading(title: String, subtitle: String? = null) {
        content.removeAllViews()
        content.addView(TextView(this).apply {
            text = title; textSize = 22f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFFEDF6FF.toInt()); setPadding(dp(2), dp(8), dp(2), dp(4))
        })
        if (subtitle != null) content.addView(TextView(this).apply {
            text = subtitle; textSize = 12f; setTextColor(0xFF93A7C3.toInt()); setPadding(dp(2), 0, dp(2), dp(12))
        })
    }

    private fun card(title: String, body: String, accent: Int = 0xFF55F4FF.toInt()) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(12))
            setBackgroundColor(0xFF111A2A.toInt())
        }
        box.addView(TextView(this).apply { text = title; textSize = 14f; typeface = Typeface.DEFAULT_BOLD; setTextColor(accent) })
        box.addView(TextView(this).apply { text = body; textSize = 12f; setTextColor(0xFFD0D9E8.toInt()); setPadding(0, dp(5), 0, 0) })
        val lp = LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, dp(5), 0, dp(7))
        content.addView(box, lp)
    }

    private fun action(label: String, callback: () -> Unit) {
        content.addView(Button(this).apply { text = label; setOnClickListener { callback() } }, LinearLayout.LayoutParams(-1, -2))
    }

    private fun showDashboard() {
        heading("CONTROL CENTER", "A modular client shell with its own interface and local module registry.")
        val installed = getMinecraftInfo()
        card("GAME INSTALLATION", if (installed == null) "Minecraft Bedrock was not detected under $gamePackage. Install status can be refreshed on the GAME screen." else "Minecraft Bedrock detected\nVersion: ${installed.versionName ?: "unknown"} (code ${installed.longVersionCodeCompat()})\nPackage: $gamePackage", if (installed == null) 0xFFFFC66D.toInt() else 0xFF65F7A5.toInt())
        val versions = listOf("1.21.90", "1.21.100", "1.21.110", "26.0", "26.10", "26.20", "26.30", "26.40", "26.50", "26.52")
        content.addView(TextView(this).apply { text = "TARGET BEDROCK VERSION (PLANNED RANGE)"; textSize = 11f; setTextColor(0xFF8CA2BF.toInt()); setPadding(dp(2), dp(8), 0, dp(2)) })
        val spinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, versions)
            setSelection(versions.indexOf(prefs.getString("targetVersion", "26.52")).coerceAtLeast(0))
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: AdapterView<*>?) {}
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    prefs.edit().putString("targetVersion", versions[position]).apply()
                    status.text = "TARGET ${versions[position]} SELECTED  //  NOT YET COMPATIBILITY-TESTED"
                }
            }
        }
        content.addView(spinner)
        card("MODULES", "${modules.count { prefs.getBoolean("module_${it.id}", false) }} / ${modules.size} local toggles enabled. They are not active in-game features yet.")
        card("PROFILES", "${profilesDir.listFiles()?.count { it.isFile && it.extension == "json" } ?: 0} local module profile(s) saved.")
        card("NATIVE IMPORTS", "${nativeDir.listFiles()?.count { it.isFile } ?: 0} .so file(s) stored privately. Import validation does not imply game compatibility.")
        action("OPEN MODULE MANAGER") { showModules() }
        action("MANAGE PROFILES") { showProfiles() }
        if (prefs.getBoolean("show_first_run_pack_notice", false)) {
            card("DEFAULT PACKS READY", "X CLIENT copied its included .mcaddon and .mcpack examples into your pack library. They will be handed to Minecraft from the launch queue; Minecraft may ask you to confirm each import.", 0xFF65F7A5.toInt())
            action("REVIEW / SEND INCLUDED PACKS") { showResourcePacks() }
            prefs.edit().putBoolean("show_first_run_pack_notice", false).apply()
        }
        action("RESOURCE PACK MANAGER / CURSEFORGE") { showResourcePacks() }
        action("LAUNCHER SETTINGS") { showSettings() }
        action("DETECT / LAUNCH MINECRAFT") { showGameDetection() }
        action("IMPORT NATIVE MODULE (.SO)") { pickFile(PICK_NATIVE, "application/octet-stream") }
    }

    private fun showModules() {
        heading("MODULE MANAGER", "Search and save preferences. Native C++ module logic exists, but no Bedrock provider is connected yet.")
        val search = EditText(this).apply { hint = "Search modules"; setSingleLine(true); setTextColor(0xFFEDF6FF.toInt()); setHintTextColor(0xFF71829B.toInt()) }
        content.addView(search)
        val categories = listOf("ALL", "HUD", "VISUAL", "UTILITY", "PERFORMANCE")
        val filter = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, categories) }
        content.addView(filter)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(list)
        fun render() {
            list.removeAllViews()
            val q = search.text.toString().trim().lowercase()
            val category = filter.selectedItem?.toString() ?: "ALL"
            val filtered = modules.filter { (category == "ALL" || it.category == category) && (q.isEmpty() || it.name.lowercase().contains(q) || it.description.lowercase().contains(q)) }
            filtered.forEach { module ->
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(10), dp(8), dp(10)); setBackgroundColor(0xFF111A2A.toInt()) }
                val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
                info.addView(TextView(this).apply { text = module.name; textSize = 14f; typeface = Typeface.DEFAULT_BOLD; setTextColor(0xFFEDF6FF.toInt()) })
                info.addView(TextView(this).apply { text = "${module.category}  •  CORE LOGIC / BRIDGE REQUIRED"; textSize = 10f; setTextColor(0xFF93A7C3.toInt()) })
                info.addView(TextView(this).apply { text = module.description; textSize = 11f; setTextColor(0xFFB5C3D7.toInt()); setPadding(0, dp(3), 0, 0) })
                row.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
                row.addView(Switch(this).apply {
                    isChecked = prefs.getBoolean("module_${module.id}", false)
                    contentDescription = "Enable ${module.name} local preference"
                    setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean("module_${module.id}", checked).apply() }
                })
                val lp = LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, dp(4), 0, dp(4)); list.addView(row, lp)
            }
            if (filtered.isEmpty()) list.addView(TextView(this).apply { text = "No modules match this filter."; setTextColor(0xFF93A7C3.toInt()); setPadding(dp(8), dp(16), dp(8), dp(16)) })
        }
        search.addTextChangedListener(SimpleTextWatcher { render() })
        filter.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) { render() }
        }
        render()
        action("IMPORT NATIVE MODULE (.SO)") { pickFile(PICK_NATIVE, "application/octet-stream") }
        action("IMPORT PACKAGE (.LEVIPACK)") { pickFile(PICK_PACKAGE, "*/*") }
    }

    private fun showProfiles() {
        heading("MODULE PROFILES", "Save and switch local module preferences. Profiles do not activate features inside Minecraft.")
        val nameInput = EditText(this).apply {
            hint = "Profile name (e.g. Survival)"; setSingleLine(true)
            setTextColor(0xFFEDF6FF.toInt()); setHintTextColor(0xFF71829B.toInt())
        }
        content.addView(nameInput)
        action("SAVE CURRENT CONFIGURATION") {
            val name = nameInput.text.toString().trim()
            if (name.isBlank()) { Toast.makeText(this, "Enter a profile name first", Toast.LENGTH_SHORT).show(); return@action }
            val safe = name.replace(Regex("[^A-Za-z0-9 _-]"), "_").trim().take(40)
            if (safe.isBlank()) { Toast.makeText(this, "That profile name is not valid", Toast.LENGTH_SHORT).show(); return@action }
            val json = JSONObject()
            json.put("name", safe)
            json.put("targetVersion", prefs.getString("targetVersion", "26.52"))
            val enabled = org.json.JSONArray()
            modules.filter { prefs.getBoolean("module_${it.id}", false) }.forEach { enabled.put(it.id) }
            json.put("enabledModules", enabled)
            File(profilesDir, "${safe}.json").writeText(json.toString(2))
            status.text = "PROFILE SAVED  //  $safe"
            showProfiles()
        }
        val files = profilesDir.listFiles()?.filter { it.isFile && it.extension == "json" }?.sortedBy { it.name.lowercase() } ?: emptyList()
        if (files.isEmpty()) card("NO SAVED PROFILES", "Create a profile above. Profiles store enabled module IDs and the selected target version.")
        files.forEach { file ->
            val displayName = try { JSONObject(file.readText()).optString("name", file.nameWithoutExtension) } catch (_: Exception) { file.nameWithoutExtension }
            card(displayName, file.name)
            action("LOAD $displayName") { loadProfile(file) }
            action("DELETE $displayName") {
                if (file.delete()) { status.text = "PROFILE DELETED  //  $displayName"; showProfiles() }
                else Toast.makeText(this, "Could not delete profile", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun loadProfile(file: File) {
        try {
            val json = JSONObject(file.readText())
            val enabled = json.optJSONArray("enabledModules") ?: org.json.JSONArray()
            val ids = (0 until enabled.length()).mapNotNull { enabled.optString(it, null) }.toSet()
            val edit = prefs.edit().putString("targetVersion", json.optString("targetVersion", "26.52"))
            modules.forEach { edit.putBoolean("module_${it.id}", it.id in ids) }
            edit.apply()
            status.text = "PROFILE LOADED  //  ${json.optString("name", file.nameWithoutExtension)}"
            showProfiles()
        } catch (e: Exception) {
            status.text = "PROFILE LOAD FAILED  //  ${e.message ?: "invalid profile"}"
        }
    }

    private fun showSettings() {
        heading("LAUNCHER SETTINGS", "Local preferences and app information.")
        val currentTarget = prefs.getString("targetVersion", "26.52") ?: "26.52"
        card("TARGET VERSION", "$currentTarget selected. This is a planning preference, not a verified compatibility claim.")
        val versions = listOf("1.21.90", "1.21.100", "1.21.110", "26.0", "26.10", "26.20", "26.30", "26.40", "26.50", "26.52")
        val selector = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, versions)
            setSelection(versions.indexOf(currentTarget).coerceAtLeast(0))
        }
        content.addView(selector)
        action("SAVE TARGET VERSION") {
            val target = selector.selectedItem?.toString() ?: "26.52"
            prefs.edit().putString("targetVersion", target).apply()
            status.text = "TARGET SAVED  //  $target NOT COMPATIBILITY-TESTED"
            Toast.makeText(this, "Target preference saved", Toast.LENGTH_SHORT).show()
            showSettings()
        }
        card("ANDROID SUPPORT", "Minimum Android: 9 (API 28). Target SDK: 36. Actual install and behavior must still be tested on devices running Android 9–16.")
        card("PRIVACY", "Module preferences and profiles are stored locally in app-private storage. Imported libraries are stored but never loaded or executed.")
        action("RESET MODULE TOGGLES") {
            val edit = prefs.edit()
            modules.forEach { edit.putBoolean("module_${it.id}", false) }
            edit.apply()
            status.text = "MODULE TOGGLES RESET"
            showSettings()
        }
        action("OPEN PROFILES") { showProfiles() }
        action("RESOURCE PACK MANAGER") { showResourcePacks() }
    }

    private fun showGameDetection() {
        heading("GAME DETECTION", "Checks the standard Minecraft Bedrock Android package. Does not inspect or modify game memory.")
        val info = getMinecraftInfo()
        if (info == null) {
            card("MINECRAFT NOT DETECTED", "No visible installed app found for $gamePackage. If Minecraft is installed, check that it is the standard Android package and refresh detection.", 0xFFFFC66D.toInt())
            action("REFRESH DETECTION") { showGameDetection() }
        } else {
            val installer = getInstallerLabel(gamePackage)
            card("MINECRAFT BEDROCK DETECTED", "App: ${applicationLabel(info)}\nPackage: $gamePackage\nVersion: ${info.versionName ?: "unknown"}\nVersion code: ${info.longVersionCodeCompat()}\nInstaller: $installer\nCPU ABIs on device: ${Build.SUPPORTED_ABIS.joinToString()}", 0xFF65F7A5.toInt())
            card("COMPATIBILITY", "Detected version is informational only. X CLIENT has not verified runtime compatibility for this build.", 0xFFFFC66D.toInt())
            action("LAUNCH MINECRAFT") { launchMinecraft() }
            action("REFRESH DETECTION") { showGameDetection() }
        }
        card("PLAY STORE AND MANUAL APK", "Both installation routes can be detected when they use the standard package ID. Android may restrict installer-source details. A manually installed APK cannot coexist with the Play Store build under the same package ID.")
        action("BACK TO HOME") { showDashboard() }
    }

    private fun showImports() {
        heading("IMPORT CENTER", "Imported files stay in X CLIENT private storage. Import is not activation.")
        action("IMPORT NATIVE LIBRARY (.SO)") { pickFile(PICK_NATIVE, "application/octet-stream") }
        action("IMPORT HOST PACKAGE (.LEVIPACK)") { pickFile(PICK_PACKAGE, "*/*") }
        action("IMPORT BEDROCK PACK (.MCPACK / .MCADDON / .ZIP)") { pickFile(PICK_RESOURCE_PACK, "*/*") }
        action("OPEN RESOURCE PACK MANAGER") { showResourcePacks() }
        card("NATIVE LIBRARY VALIDATION", "Checks the ELF header and CPU architecture before storage. This does not prove that a library is safe or compatible; imported code is never loaded or injected.")
        card("STORED NATIVE LIBRARIES", listFiles(nativeDir))
        card("STORED PACKAGES", listFiles(packageDir))
    }

    private fun showRuntime() {
        heading("RUNTIME STATUS", "Independent C++ module core and explicit game-bridge boundary")
        card("STATUS: CORE IMPLEMENTED / GAME BRIDGE MISSING", "The portable C++20 module manager implements coordinate, compass, sprint-status, and crosshair drawing logic. It requires a provider implementing IGameBridge; no Bedrock provider is connected, so these features do not render in Minecraft yet.", 0xFFFFC66D.toInt())
        card("TEST STATUS", "The native host test suite passes against a synthetic test bridge. This verifies module logic only, not Minecraft integration.")
        card("COMPATIBILITY TARGET", "Requested range: Bedrock 1.21.90 through 26.52. No game versions are marked verified. A legitimate, version-tested provider is still required.")
        card("INDEPENDENT RUNTIME", "X CLIENT does not include Mojang's proprietary Bedrock engine. The current implementation provides a runtime API boundary, not a replacement game engine.")
        action("CHECK INSTALLED GAME") { showGameDetection() }
    }

    private fun showResourcePacks() {
        heading("RESOURCE PACKS", "Included example packs are copied into this library on first launch. You can also add your own packs or search CurseForge.")
        action("＋ IMPORT YOUR OWN PACK  (.MCPACK / .MCADDON / .ZIP)") {
            pickFile(PICK_RESOURCE_PACK, "*/*")
        }
        action("QUEUE INCLUDED PACKS AGAIN") { requeueBundledPacks(); showResourcePacks() }
        val autoImport = Switch(this).apply {
            text = "AUTO-SEND QUEUED PACKS WHEN LAUNCHING MINECRAFT"
            setTextColor(0xFFEDF6FF.toInt())
            textSize = 12f
            isChecked = prefs.getBoolean("auto_send_packs_on_launch", true)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("auto_send_packs_on_launch", checked).apply()
                status.text = if (checked) "AUTO PACK HANDOFF ENABLED" else "AUTO PACK HANDOFF DISABLED"
            }
        }
        content.addView(autoImport)
        val sentPacks = prefs.getStringSet("packs_handed_off", emptySet()) ?: emptySet()
        val pendingCount = (packsDir.listFiles()?.filter { it.isFile } ?: emptyList()).count { it.name !in sentPacks }
        card("AUTOMATIC IMPORT", "$pendingCount pack(s) waiting to be sent to Minecraft. With auto-send enabled, press LAUNCH MINECRAFT on the GAME screen: X CLIENT opens the next queued pack in Minecraft. If you have multiple packs, repeat for each pack. Minecraft may display its own import confirmation; X CLIENT cannot silently write into Minecraft's private storage or guarantee activation in a world.")
        val keyInput = EditText(this).apply {
            hint = "CurseForge API key (required)"; setSingleLine(true); inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            setTextColor(0xFFEDF6FF.toInt()); setHintTextColor(0xFF71829B.toInt()); setText(prefs.getString("curseforge_api_key", ""))
        }
        content.addView(keyInput)
        val gameIdInput = EditText(this).apply {
            hint = "CurseForge game ID (default 432: Minecraft)"; setSingleLine(true); inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setTextColor(0xFFEDF6FF.toInt()); setHintTextColor(0xFF71829B.toInt()); setText(prefs.getString("curseforge_game_id", "432"))
        }
        content.addView(gameIdInput)
        val classIdInput = EditText(this).apply {
            hint = "Class ID (default 4559: Addons; verify Bedrock category)"; setSingleLine(true); inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setTextColor(0xFFEDF6FF.toInt()); setHintTextColor(0xFF71829B.toInt()); setText(prefs.getString("curseforge_class_id", "4559"))
        }
        content.addView(classIdInput)
        val queryInput = EditText(this).apply {
            hint = "Search packs (e.g. Bedrock textures)"; setSingleLine(true)
            setTextColor(0xFFEDF6FF.toInt()); setHintTextColor(0xFF71829B.toInt())
        }
        content.addView(queryInput)
        val versionInput = EditText(this).apply {
            hint = "Bedrock version filter (optional)"; setSingleLine(true); setText(prefs.getString("targetVersion", "26.52"))
            setTextColor(0xFFEDF6FF.toInt()); setHintTextColor(0xFF71829B.toInt())
        }
        content.addView(versionInput)
        val results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        action("SAVE API SETTINGS") {
            val key = keyInput.text.toString().trim()
            val gameId = gameIdInput.text.toString().toIntOrNull()
            val classId = classIdInput.text.toString().toIntOrNull()
            if (gameId == null || gameId <= 0 || classId == null || classId <= 0) { Toast.makeText(this, "Enter valid numeric game and class IDs", Toast.LENGTH_LONG).show(); return@action }
            prefs.edit().putString("curseforge_api_key", key).putString("curseforge_game_id", gameId.toString()).putString("curseforge_class_id", classId.toString()).apply()
            status.text = "CURSEFORGE SETTINGS SAVED LOCALLY"
            Toast.makeText(this, "Settings saved on this device", Toast.LENGTH_SHORT).show()
        }
        action("SEARCH CURSEFORGE") {
            val key = keyInput.text.toString().trim()
            val gameId = gameIdInput.text.toString().toIntOrNull()
            val classId = classIdInput.text.toString().toIntOrNull()
            if (key.isBlank()) { Toast.makeText(this, "A valid CurseForge API key is required", Toast.LENGTH_LONG).show(); return@action }
            if (gameId == null || gameId <= 0 || classId == null || classId <= 0) { Toast.makeText(this, "Enter valid numeric game and class IDs", Toast.LENGTH_LONG).show(); return@action }
            prefs.edit().putString("curseforge_api_key", key).putString("curseforge_game_id", gameId.toString()).putString("curseforge_class_id", classId.toString()).apply()
            results.removeAllViews()
            results.addView(TextView(this).apply { text = "CONTACTING CURSEFORGE API…"; setTextColor(0xFF55F4FF.toInt()); setPadding(0, dp(12), 0, dp(12)) })
            val query = queryInput.text.toString().trim()
            val version = versionInput.text.toString().trim()
            Thread {
                try {
                    val found = CurseForgeClient(key).search(query, gameId, classId, version)
                    runOnUiThread {
                        results.removeAllViews()
                        if (found.isEmpty()) results.addView(TextView(this).apply { text = "No results. Check the game/class IDs, version filter, and API access."; setTextColor(0xFFFFC66D.toInt()); setPadding(0, dp(12), 0, dp(12)) })
                        found.forEach { project ->
                            val cardBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(10), dp(12), dp(10)); setBackgroundColor(0xFF111A2A.toInt()) }
                            cardBox.addView(TextView(this).apply { text = project.name; textSize = 15f; typeface = Typeface.DEFAULT_BOLD; setTextColor(0xFF55F4FF.toInt()) })
                            cardBox.addView(TextView(this).apply { text = "${project.downloads} downloads  •  file: ${project.fileName.ifBlank { "main file" }}\n${project.summary}"; textSize = 11f; setTextColor(0xFFD0D9E8.toInt()); setPadding(0, dp(4), 0, dp(4)) })
                            val downloadButton = Button(this).apply { text = "DOWNLOAD TO X CLIENT"; setOnClickListener {
                                isEnabled = false; text = "DOWNLOADING…"
                                Thread {
                                    try {
                                        val saved = CurseForgeClient(key).download(project, packsDir)
                                        runOnUiThread { status.text = "PACK DOWNLOADED  //  ${saved.name}"; Toast.makeText(this@MainActivity, "Saved pack: ${saved.name}", Toast.LENGTH_LONG).show(); showResourcePacks() }
                                    } catch (e: Exception) {
                                        runOnUiThread { isEnabled = true; text = "RETRY DOWNLOAD"; status.text = "DOWNLOAD FAILED  //  ${e.message ?: "unknown error"}"; Toast.makeText(this@MainActivity, e.message ?: "Download failed", Toast.LENGTH_LONG).show() }
                                    }
                                }.start()
                            } }
                            cardBox.addView(downloadButton)
                            val lp = LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, dp(6), 0, dp(6)); results.addView(cardBox, lp)
                        }
                    }
                } catch (e: Exception) {
                    runOnUiThread { results.removeAllViews(); results.addView(TextView(this).apply { text = "SEARCH FAILED\n${e.message ?: "Unknown error"}\n\nCurseForge requires an approved API key. Check the configured game/class IDs and API access."; setTextColor(0xFFFFC66D.toInt()); setPadding(0, dp(12), 0, dp(12)) }) }
                }
            }.start()
        }
        content.addView(results)
        card("API ACCESS", "CurseForge requires an approved API key in the x-api-key header. Get one through CurseForge for Studios; do not share it publicly. This app stores the key in private app preferences, but a production release should use a backend proxy to avoid shipping a shared developer key.")
        card("LOCAL PACK LIBRARY", "${packsDir.listFiles()?.count { it.isFile } ?: 0} pack file(s) stored in X CLIENT. Downloads do not automatically activate inside Minecraft.")
        action("＋ IMPORT ANOTHER PACK FROM DEVICE") { pickFile(PICK_RESOURCE_PACK, "*/*") }
        action("REFRESH LOCAL LIBRARY") { showResourcePacks() }
        val local = packsDir.listFiles()?.filter { it.isFile }?.sortedByDescending { it.lastModified() } ?: emptyList()
        if (local.isEmpty()) card("NO LOCAL PACKS", "Download a pack from CurseForge or import an existing .mcpack, .mcaddon, or .zip file.")
        local.forEach { file ->
            card(file.name, "${file.length()} bytes  •  stored in X CLIENT private storage")
            action("IMPORT INTO MINECRAFT: ${file.name.take(24)}") { handPackToMinecraft(file) }
            action("DELETE: ${file.name.take(28)}") { if (file.delete()) showResourcePacks() else Toast.makeText(this, "Could not delete pack", Toast.LENGTH_SHORT).show() }
        }
    }

    private fun requeueBundledPacks() {
        val bundled = setOf("X_CLIENT_Gameplay_Addons_v0.8.mcaddon", "X_CLIENT_HUD_BP_v0.8.mcpack", "X_CLIENT_Crosshair_RP_v0.8.mcpack")
        val sent = (prefs.getStringSet("packs_handed_off", emptySet()) ?: emptySet()).toMutableSet()
        sent.removeAll(bundled)
        prefs.edit().putStringSet("packs_handed_off", sent).apply()
        Toast.makeText(this, "Included packs queued. Launch Minecraft to hand them off one at a time.", Toast.LENGTH_LONG).show()
    }

    private fun handPackToMinecraft(file: File): Boolean {
        try {
            val uri = androidx.core.content.FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, when (file.extension.lowercase()) { "mcpack", "mcaddon" -> "application/octet-stream"; else -> "application/zip" })
                setPackage(gamePackage)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            if (intent.resolveActivity(packageManager) == null) {
                status.text = "IMPORT HANDOFF UNAVAILABLE  //  MINECRAFT HAS NO VISIBLE FILE HANDLER"
                Toast.makeText(this, "Minecraft did not advertise a handler for this pack. Try opening it through Android Files.", Toast.LENGTH_LONG).show()
                return false
            }
            startActivity(intent)
            val sent = (prefs.getStringSet("packs_handed_off", emptySet()) ?: emptySet()).toMutableSet()
            sent.add(file.name)
            prefs.edit().putStringSet("packs_handed_off", sent).apply()
            status.text = "PACK SENT TO MINECRAFT  //  IMPORT/ACTIVATION MAY REQUIRE CONFIRMATION"
            return true
        } catch (e: Exception) {
            status.text = "PACK HANDOFF FAILED  //  ${e.message ?: "unknown error"}"
            Toast.makeText(this, "Could not hand pack to Minecraft", Toast.LENGTH_LONG).show()
            return false
        }
    }

    private fun getMinecraftInfo(): PackageInfo? = try {
        if (Build.VERSION.SDK_INT >= 33) packageManager.getPackageInfo(gamePackage, PackageManager.PackageInfoFlags.of(0L))
        else packageManager.getPackageInfo(gamePackage, 0)
    } catch (_: PackageManager.NameNotFoundException) { null }

    private fun PackageInfo.longVersionCodeCompat(): Long = if (Build.VERSION.SDK_INT >= 28) longVersionCode else versionCode.toLong()

    private fun applicationLabel(info: PackageInfo): String = try { packageManager.getApplicationLabel(info.applicationInfo!!).toString() } catch (_: Exception) { "Minecraft" }

    private fun getInstallerLabel(pkg: String): String = try {
        val source = if (Build.VERSION.SDK_INT >= 30) packageManager.getInstallSourceInfo(pkg).installingPackageName else packageManager.getInstallerPackageName(pkg)
        when (source) {
            "com.android.vending" -> "Google Play Store (reported by Android)"
            null -> "Unknown / unavailable"
            else -> "Other installer: $source"
        }
    } catch (_: Exception) { "Unknown / unavailable" }

    private fun launchMinecraft() {
        if (prefs.getBoolean("auto_send_packs_on_launch", true)) {
            val sent = prefs.getStringSet("packs_handed_off", emptySet()) ?: emptySet()
            val nextPack = packsDir.listFiles()?.filter { it.isFile && it.name !in sent }?.minByOrNull { it.lastModified() }
            if (nextPack != null) {
                if (handPackToMinecraft(nextPack)) {
                    Toast.makeText(this, "Queued pack sent to Minecraft. If more packs remain, press Launch Minecraft again after returning to X CLIENT.", Toast.LENGTH_LONG).show()
                }
                return
            }
        }
        val launch = packageManager.getLaunchIntentForPackage(gamePackage)
        if (launch == null) {
            status.text = "LAUNCH FAILED  //  GAME NOT VISIBLE OR NO LAUNCH ACTIVITY"
            Toast.makeText(this, "Minecraft launch activity not found", Toast.LENGTH_LONG).show()
            return
        }
        try { startActivity(launch); status.text = "MINECRAFT LAUNCH REQUEST SENT  //  X CLIENT RUNTIME NOT ATTACHED" }
        catch (e: Exception) { status.text = "LAUNCH FAILED: ${e.message ?: "unknown error"}" }
    }

    private fun validateElf(file: File): String? {
        if (file.length() < 20) return "File is too small to be a valid ELF shared library."
        val bytes = file.inputStream().use { it.readNBytesCompat(20) }
        if (bytes.size < 20 || bytes[0] != 0x7f.toByte() || bytes[1] != 'E'.code.toByte() || bytes[2] != 'L'.code.toByte() || bytes[3] != 'F'.code.toByte()) return "Invalid ELF header; file was not imported."
        val endian = bytes[5].toInt() and 0xff
        if (endian != 1) return "Unsupported ELF byte order; file was not imported."
        val machine = (bytes[18].toInt() and 0xff) or ((bytes[19].toInt() and 0xff) shl 8)
        val abi = when (machine) { 183 -> "arm64-v8a"; 40 -> "armeabi-v7a"; 62 -> "x86_64"; 3 -> "x86"; else -> return "Unknown ELF CPU type ($machine); file was not imported." }
        if (abi !in Build.SUPPORTED_ABIS) return "Library targets $abi, not supported by this device (${Build.SUPPORTED_ABIS.joinToString()})."
        return null
    }

    private fun listFiles(dir: File): String {
        val files = dir.listFiles()?.filter { it.isFile }?.sortedByDescending { it.lastModified() } ?: emptyList()
        return if (files.isEmpty()) "None imported yet." else files.joinToString("\n") { "• ${it.name} (${it.length()} bytes)" }
    }

    private fun pickFile(requestCode: Int, mime: String) {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = mime }, requestCode)
    }

    @Deprecated("Legacy callback retained for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) return
        val uri = data.data!!
        try {
            val displayName = queryDisplayName(uri) ?: "import_${System.currentTimeMillis()}"
            val isNative = requestCode == PICK_NATIVE
            if (requestCode !in setOf(PICK_NATIVE, PICK_PACKAGE, PICK_RESOURCE_PACK)) return
            val isResourcePack = requestCode == PICK_RESOURCE_PACK
            if (isNative && !displayName.endsWith(".so", true)) { status.text = "Import rejected: choose a .so file."; return }
            if (requestCode == PICK_PACKAGE && !displayName.endsWith(".levipack", true)) { status.text = "Import rejected: choose a .levipack package."; return }
            if (isResourcePack && !displayName.endsWith(".mcpack", true) && !displayName.endsWith(".mcaddon", true) && !displayName.endsWith(".zip", true)) { status.text = "Import rejected: choose .mcpack, .mcaddon, or .zip."; return }
            val safeName = displayName.substringAfterLast('/').replace(Regex("[^A-Za-z0-9._-]"), "_")
            val temp = File(cacheDir, "validate_${System.currentTimeMillis()}_$safeName")
            contentResolver.openInputStream(uri).use { input -> requireNotNull(input) { "Selected file could not be read" }; FileOutputStream(temp).use { output -> input.copyTo(output) } }
            if (temp.length() > 64L * 1024L * 1024L) {
                temp.delete()
                status.text = "Import rejected: files must be 64 MiB or smaller."
                Toast.makeText(this, "File exceeds 64 MiB import limit", Toast.LENGTH_LONG).show()
                return
            }
            if (isNative) {
                val problem = validateElf(temp)
                if (problem != null) { temp.delete(); status.text = "Import rejected: $problem"; Toast.makeText(this, problem, Toast.LENGTH_LONG).show(); showImports(); return }
            }
            val destDir = when { isNative -> nativeDir; isResourcePack -> packsDir; else -> packageDir }
            val dest = File(destDir, "${System.currentTimeMillis()}_$safeName")
            if (!temp.renameTo(dest)) { temp.copyTo(dest, overwrite = true); temp.delete() }
            if (isResourcePack) {
                val sent = (prefs.getStringSet("packs_handed_off", emptySet()) ?: emptySet()).toMutableSet()
                sent.remove(dest.name)
                prefs.edit().putStringSet("packs_handed_off", sent).apply()
            }
            status.text = "Stored ${dest.name}. Not yet sent to Minecraft; game compatibility is unverified."
            Toast.makeText(this, "Imported to private storage", Toast.LENGTH_LONG).show()
            if (isResourcePack) showResourcePacks() else showImports()
        } catch (e: Exception) { status.text = "Import failed: ${e.message ?: "unknown error"}" }
    }

    private fun queryDisplayName(uri: Uri): String? {
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor -> if (cursor.moveToFirst()) return cursor.getString(0) }
        return uri.lastPathSegment
    }

    private fun java.io.InputStream.readNBytesCompat(count: Int): ByteArray { val out = ByteArray(count); var offset = 0; while (offset < count) { val n = read(out, offset, count - offset); if (n <= 0) break; offset += n }; return if (offset == count) out else out.copyOf(offset) }
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    data class Module(val id: String, val name: String, val category: String, val description: String)
}

private class SimpleTextWatcher(private val changed: () -> Unit) : TextWatcher {
    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { changed() }
    override fun afterTextChanged(s: Editable?) {}
}
