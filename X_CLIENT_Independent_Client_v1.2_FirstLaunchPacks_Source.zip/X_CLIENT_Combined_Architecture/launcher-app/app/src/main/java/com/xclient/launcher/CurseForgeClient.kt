package com.xclient.launcher

import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Minimal CurseForge Core API client. API keys are supplied at runtime, never embedded in source. */
internal class CurseForgeClient(private val apiKey: String) {
    data class Project(
        val id: Int,
        val name: String,
        val summary: String,
        val downloads: Long,
        val pageUrl: String,
        val fileId: Int,
        val fileName: String
    )

    private fun request(url: String, connectTimeout: Int = 12000, readTimeout: Int = 20000): HttpURLConnection {
        val connection = URL(url).openConnection() as HttpURLConnection
        connection.connectTimeout = connectTimeout
        connection.readTimeout = readTimeout
        connection.setRequestProperty("Accept", "application/json")
        connection.setRequestProperty("x-api-key", apiKey)
        connection.setRequestProperty("User-Agent", "XCLIENT-Android-ResourceManager/0.9")
        return connection
    }

    fun search(query: String, gameId: Int, classId: Int, gameVersion: String, index: Int = 0): List<Project> {
        require(apiKey.isNotBlank()) { "Enter a CurseForge API key first." }
        val params = mutableListOf(
            "gameId=$gameId", "classId=$classId", "index=$index", "pageSize=20",
            "sortField=2", "sortOrder=desc"
        )
        if (query.isNotBlank()) params += "searchFilter=${enc(query)}"
        if (gameVersion.isNotBlank()) params += "gameVersion=${enc(gameVersion)}"
        val json = getJson("https://api.curseforge.com/v1/mods/search?${params.joinToString("&")}")
        val data = json.optJSONArray("data") ?: return emptyList()
        return (0 until data.length()).mapNotNull { i ->
            val item = data.optJSONObject(i) ?: return@mapNotNull null
            val files = item.optJSONArray("latestFiles")
            val mainId = item.optInt("mainFileId", 0)
            var fileName = ""
            var fileId = mainId
            if (files != null) {
                for (j in 0 until files.length()) {
                    val f = files.optJSONObject(j) ?: continue
                    if (f.optInt("id") == mainId || fileId == 0) {
                        fileId = f.optInt("id", fileId)
                        fileName = f.optString("fileName", "")
                        if (f.optInt("id") == mainId) break
                    }
                }
            }
            if (fileId <= 0) return@mapNotNull null
            Project(
                id = item.optInt("id"), name = item.optString("name", "Untitled project"),
                summary = item.optString("summary", ""), downloads = item.optLong("downloadCount"),
                pageUrl = item.optJSONObject("links")?.optString("websiteUrl", "") ?: "",
                fileId = fileId, fileName = fileName
            )
        }
    }

    fun download(project: Project, targetDir: File, maxBytes: Long = 128L * 1024L * 1024L): File {
        require(apiKey.isNotBlank()) { "Enter a CurseForge API key first." }
        val urlEndpoint = "https://api.curseforge.com/v1/mods/${project.id}/files/${project.fileId}/download-url"
        val json = getJson(urlEndpoint)
        val downloadUrl = json.optString("data", "")
        require(downloadUrl.startsWith("https://")) { "CurseForge did not return a valid HTTPS download URL for this file." }
        val uri = URL(downloadUrl)
        require(uri.host.isNotBlank()) { "Invalid download host." }
        // Only follow HTTPS redirects and only send the API key to CurseForge-controlled hosts.
        var current = uri
        var connection: HttpURLConnection? = null
        repeat(5) { hop ->
            connection = current.openConnection() as HttpURLConnection
            connection!!.instanceFollowRedirects = false
            connection!!.connectTimeout = 15000
            connection!!.readTimeout = 30000
            connection!!.setRequestProperty("User-Agent", "XCLIENT-Android-ResourceManager/0.9")
            if (isCurseForgeHost(current.host)) connection!!.setRequestProperty("x-api-key", apiKey)
            val code = connection!!.responseCode
            if (code in 300..399) {
                val location = connection!!.getHeaderField("Location") ?: error("Download redirect had no location.")
                connection!!.disconnect()
                current = URL(current, location)
                require(current.protocol == "https") { "Refusing non-HTTPS download redirect." }
                if (hop == 4) error("Too many download redirects.")
            } else {
                require(code in 200..299) { "Download failed with HTTP $code. Check the API key, file availability, and CurseForge access." }
                val length = connection!!.contentLengthLong
                require(length <= maxBytes || length < 0) { "Download exceeds the 128 MiB safety limit." }
                targetDir.mkdirs()
                val rawName = project.fileName
                require(rawName.isNotBlank()) { "CurseForge did not provide a file name, so the pack type cannot be verified." }
                val safeName = rawName.substringAfterLast('/').replace(Regex("[^A-Za-z0-9._-]"), "_")
                val extension = safeName.substringAfterLast('.', "").lowercase()
                require(extension in setOf("mcpack", "mcaddon", "zip")) {
                    "This file is not labelled as a Bedrock pack (.mcpack, .mcaddon, or .zip). Refusing to install it automatically."
                }
                val output = File(targetDir, "${System.currentTimeMillis()}_$safeName")
                try {
                    connection!!.inputStream.use { input -> FileOutputStream(output).use { out ->
                        val buffer = ByteArray(16 * 1024)
                        var total = 0L
                        while (true) {
                            val count = input.read(buffer)
                            if (count < 0) break
                            total += count
                            require(total <= maxBytes) { "Download exceeded the 128 MiB safety limit." }
                            out.write(buffer, 0, count)
                        }
                    } }
                    require(output.length() > 0) { "Downloaded file was empty." }
                    return output
                } catch (e: Exception) { output.delete(); throw e }
            }
        }
        connection?.disconnect()
        error("Unable to download file.")
    }

    private fun getJson(url: String): JSONObject {
        val connection = request(url)
        try {
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                val hint = when (code) {
                    401, 403 -> "CurseForge rejected the API key. A valid approved API key is required."
                    429 -> "CurseForge rate limit reached. Wait and try again."
                    else -> "CurseForge API returned HTTP $code."
                }
                error("$hint ${body.take(240)}")
            }
            return JSONObject(body)
        } finally { connection.disconnect() }
    }

    private fun isCurseForgeHost(host: String): Boolean = host.equals("curseforge.com", true) || host.endsWith(".curseforge.com", true) || host.equals("forgecdn.net", true) || host.endsWith(".forgecdn.net", true)
    private fun enc(value: String): String = URLEncoder.encode(value, "UTF-8")
}
