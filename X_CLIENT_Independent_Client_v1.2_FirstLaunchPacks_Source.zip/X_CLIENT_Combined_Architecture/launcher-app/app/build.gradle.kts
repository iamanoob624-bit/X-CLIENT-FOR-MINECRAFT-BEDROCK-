plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.xclient.launcher"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.xclient.launcher"
        minSdk = 28
        targetSdk = 36
        versionCode = 10
        versionName = "1.2.0"
    }
}
dependencies { implementation("androidx.core:core-ktx:1.15.0") }
